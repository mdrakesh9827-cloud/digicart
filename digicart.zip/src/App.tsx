/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Papa from 'papaparse';
import { 
  ShoppingBag, 
  Plus, 
  User, 
  LogOut, 
  Search, 
  Download, 
  Tag, 
  LayoutDashboard, 
  Store,
  ChevronRight,
  Loader2,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Moon,
  Sun,
  ArrowUpDown,
  Star,
  Package,
  TrendingUp,
  DollarSign,
  Wallet,
  Globe,
  FileUp,
  Twitter,
  Github,
  Linkedin,
  MapPin,
  Shield,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { format, subDays, isSameDay, startOfDay } from 'date-fns';
import { useAuthState } from 'react-firebase-hooks/auth';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  serverTimestamp,
  orderBy,
  getDoc,
  setDoc
} from 'firebase/firestore';
import { auth, db, signInWithGoogle, logout, handleFirestoreError, OperationType, generateProductImage } from './firebase';
import { cn } from './lib/utils';

// --- Types ---
interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  bio?: string;
  location?: string;
  website?: string;
  twitter?: string;
  github?: string;
  linkedin?: string;
  role: 'user' | 'admin';
  sellerStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  balance?: number;
  verification?: {
    fullName: string;
    idType: string;
    idNumber: string;
    expertise: string;
    verifiedAt?: any;
  };
  createdAt: any;
  updatedAt?: any;
}

interface ProductVariant {
  id: string;
  name: string;
  price: number;
  downloadUrl?: string;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  sellerId: string;
  sellerName: string;
  sellerStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  downloadUrl: string;
  imageUrl?: string;
  category: string;
  subCategory?: string;
  tags?: string[];
  salesCount?: number;
  averageRating?: number;
  ratingCount?: number;
  isAiGenerated?: boolean;
  variants?: ProductVariant[];
  createdAt: any;
  updatedAt: any;
}

interface Review {
  id: string;
  userId: string;
  userName: string;
  productId: string;
  rating: number;
  comment: string;
  createdAt: any;
}

interface Order {
  id: string;
  buyerId: string;
  sellerId: string;
  productId: string;
  variantId?: string | null;
  productName: string;
  price: number;
  status: 'pending' | 'completed' | 'failed';
  createdAt: any;
}

interface PayoutRequest {
  id: string;
  sellerId: string;
  sellerName: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
  processedAt?: any;
}

type View = 'marketplace' | 'seller-dashboard' | 'my-purchases' | 'admin-panel' | 'profile';
type SortOption = 'newest' | 'price-low' | 'price-high' | 'popularity';

// --- Components ---

const Navbar = ({ 
  user, 
  userProfile,
  currentView, 
  setView,
  isDarkMode,
  toggleDarkMode
}: { 
  user: any; 
  userProfile: UserProfile | null;
  currentView: View; 
  setView: (view: View) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}) => {
  return (
    <nav className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white/80 backdrop-blur-md dark:border-gray-800 dark:bg-gray-900/80">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <div 
          className="flex cursor-pointer items-center gap-2" 
          onClick={() => setView('marketplace')}
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none">
            <ShoppingBag size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight text-gray-900 dark:text-white">DigiCart</span>
        </div>

        <div className="hidden items-center gap-8 md:flex">
          <button 
            onClick={() => setView('marketplace')}
            className={cn(
              "text-sm font-medium transition-colors hover:text-indigo-600",
              currentView === 'marketplace' ? "text-indigo-600" : "text-gray-500 dark:text-gray-400 dark:hover:text-indigo-400"
            )}
          >
            Marketplace
          </button>
          {user && (
            <>
              <button 
                onClick={() => setView('my-purchases')}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-indigo-600",
                  currentView === 'my-purchases' ? "text-indigo-600" : "text-gray-500 dark:text-gray-400 dark:hover:text-indigo-400"
                )}
              >
                My Purchases
              </button>
              <button 
                onClick={() => setView('seller-dashboard')}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-indigo-600",
                  currentView === 'seller-dashboard' ? "text-indigo-600" : "text-gray-500 dark:text-gray-400 dark:hover:text-indigo-400"
                )}
              >
                Seller Dashboard
              </button>
              {userProfile?.role === 'admin' && (
                <button 
                  onClick={() => setView('admin-panel')}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-indigo-600",
                    currentView === 'admin-panel' ? "text-indigo-600" : "text-gray-500 dark:text-gray-400 dark:hover:text-indigo-400"
                  )}
                >
                  Admin Panel
                </button>
              )}
              <button 
                onClick={() => setView('profile')}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-indigo-600",
                  currentView === 'profile' ? "text-indigo-600" : "text-gray-500 dark:text-gray-400 dark:hover:text-indigo-400"
                )}
              >
                Profile
              </button>
            </>
          )}
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={toggleDarkMode}
            className="rounded-full p-2 text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800 transition-all"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          {user ? (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setView('profile')}
                className="flex items-center gap-3 text-left transition-opacity hover:opacity-80"
              >
                <div className="hidden text-right md:block">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">{userProfile?.displayName || user.displayName}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{user.email}</p>
                </div>
                <img 
                  src={userProfile?.photoURL || user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} 
                  alt={user.displayName}
                  className={cn(
                    "h-9 w-9 rounded-full border transition-all",
                    currentView === 'profile' ? "border-indigo-600 ring-2 ring-indigo-600/20" : "border-gray-200 dark:border-gray-700"
                  )}
                />
              </button>
              <button 
                onClick={logout}
                className="rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-red-600 dark:hover:bg-gray-800 transition-all"
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <button 
              onClick={signInWithGoogle}
              className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2 text-sm font-semibold text-white shadow-md hover:bg-indigo-700 transition-all active:scale-95"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </nav>
  );
};

const ProductCard = ({ 
  product, 
  onBuy, 
  isOwner, 
  onEdit, 
  onDelete,
  onClick
}: { 
  product: Product; 
  onBuy?: (p: Product) => void;
  isOwner?: boolean;
  onEdit?: (p: Product) => void;
  onDelete?: (p: Product) => void;
  onClick?: (p: Product) => void;
}) => {
  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      onClick={() => onClick?.(product)}
      className="group overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-all hover:shadow-xl hover:shadow-indigo-50/50 dark:border-gray-800 dark:bg-gray-900 dark:hover:shadow-indigo-900/20 cursor-pointer"
    >
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-gray-100 dark:bg-gray-800">
        <img 
          src={product.imageUrl || `https://picsum.photos/seed/${product.id}/800/600`} 
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <span className="rounded-full bg-white/90 px-3 py-1 text-xs font-bold text-indigo-600 backdrop-blur-sm dark:bg-gray-900/90 dark:text-indigo-400">
            {product.category}
          </span>
          {product.isAiGenerated && (
            <span className="rounded-full bg-indigo-600/90 px-3 py-1 text-[10px] font-bold text-white backdrop-blur-sm flex items-center gap-1">
              <Globe size={10} className="animate-pulse" />
              AI Generated
            </span>
          )}
        </div>
      </div>
      <div className="p-5">
        <div className="mb-2 flex items-start justify-between">
          <div className="flex flex-col">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white line-clamp-1">{product.name}</h3>
            <div className="flex items-center gap-2">
              {product.ratingCount && product.ratingCount > 0 ? (
                <div className="flex items-center gap-1">
                  <div className="flex items-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star} 
                        size={10} 
                        fill={star <= Math.round(product.averageRating || 0) ? "currentColor" : "none"} 
                        className={star <= Math.round(product.averageRating || 0) ? "text-amber-500" : "text-gray-300 dark:text-gray-700"}
                      />
                    ))}
                  </div>
                  <span className="text-xs font-bold text-amber-500">{product.averageRating?.toFixed(1)}</span>
                  <span className="text-[10px] text-gray-400 dark:text-gray-500">({product.ratingCount})</span>
                </div>
              ) : (
                <div className="flex items-center gap-1 text-[10px] font-medium text-gray-400">
                  <Star size={10} />
                  <span>No ratings</span>
                </div>
              )}
            </div>
          </div>
        </div>
        <p className="mb-4 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{product.description}</p>
        
        <div className="flex items-center justify-between border-t border-gray-50 dark:border-gray-800 pt-4">
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center text-[10px] font-bold text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300">
                {product.sellerName.charAt(0)}
              </div>
              {product.sellerStatus === 'approved' && (
                <div className="absolute -bottom-1 -right-1 rounded-full bg-white p-0.5 dark:bg-gray-900">
                  <CheckCircle2 size={10} className="text-green-500 fill-green-500/10" />
                </div>
              )}
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                {product.sellerName}
                {product.sellerStatus === 'approved' && (
                  <span className="text-[8px] font-bold text-green-600 dark:text-green-400 uppercase tracking-tighter">Verified</span>
                )}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <span className="text-xl font-black text-indigo-600 dark:text-indigo-400">${product.price}</span>
            {isOwner ? (
              <div className="flex gap-1">
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(product);
                  }}
                  className="rounded-lg p-2 text-gray-400 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-900/50 dark:hover:text-indigo-400 transition-colors"
                >
                  <Edit2 size={16} />
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete?.(product);
                  }}
                  className="rounded-lg p-2 text-gray-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/50 dark:hover:text-red-400 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ) : (
              product.sellerId !== auth.currentUser?.uid && (
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    onBuy?.(product);
                  }}
                  className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 dark:shadow-none"
                >
                  <ShoppingBag size={16} />
                  Buy Now
                </button>
              )
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const ReviewForm = ({ 
  productId, 
  onSubmit 
}: { 
  productId: string; 
  onSubmit: (rating: number, comment: string) => Promise<void> 
}) => {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (comment.trim().length === 0) return;
    setIsSubmitting(true);
    try {
      await onSubmit(rating, comment);
      setComment('');
      setRating(5);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 rounded-2xl bg-gray-50 p-6 dark:bg-gray-800/50">
      <h4 className="font-bold text-gray-900 dark:text-white">Leave a Review</h4>
      <div className="flex items-center gap-2">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className={cn(
              "transition-all active:scale-90",
              rating >= star ? "text-amber-500" : "text-gray-300 dark:text-gray-600"
            )}
          >
            <Star size={24} fill={rating >= star ? "currentColor" : "none"} />
          </button>
        ))}
      </div>
      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Share your thoughts about this product..."
        className="w-full rounded-xl border border-gray-200 bg-white p-4 text-sm focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-700 dark:bg-gray-900 dark:text-white"
        rows={3}
        required
      />
      <button
        type="submit"
        disabled={isSubmitting || comment.trim().length === 0}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 py-3 font-bold text-white shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 dark:shadow-none"
      >
        {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : 'Submit Review'}
      </button>
    </form>
  );
};

const ProductDetailsModal = ({ 
  product, 
  isOpen, 
  onClose, 
  onBuy, 
  reviews,
  hasPurchased,
  onAddReview
}: { 
  product: Product | null; 
  isOpen: boolean; 
  onClose: () => void; 
  onBuy: (p: Product, variant?: ProductVariant) => void;
  reviews: Review[];
  hasPurchased: boolean;
  onAddReview: (productId: string, rating: number, comment: string) => Promise<void>;
}) => {
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);

  useEffect(() => {
    setSelectedVariant(null);
  }, [product, isOpen]);

  if (!product) return null;

  const productReviews = reviews.filter(r => r.productId === product.id);
  const userHasReviewed = productReviews.some(r => r.userId === auth.currentUser?.uid);

  const currentPrice = selectedVariant ? selectedVariant.price : product.price;

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 sm:p-6">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-4xl max-h-[90vh] overflow-hidden rounded-[2.5rem] bg-white shadow-2xl dark:bg-gray-900"
          >
            <button 
              onClick={onClose}
              className="absolute top-6 right-6 z-10 rounded-full bg-white/80 p-2 text-gray-500 backdrop-blur-md hover:bg-white hover:text-gray-900 dark:bg-gray-800/80 dark:text-gray-400 dark:hover:bg-gray-800 dark:hover:text-white"
            >
              <X size={24} />
            </button>

            <div className="flex h-full flex-col md:flex-row overflow-y-auto">
              {/* Product Image */}
              <div className="w-full md:w-1/2 bg-gray-100 dark:bg-gray-800">
                <img 
                  src={product.imageUrl || `https://picsum.photos/seed/${product.id}/800/800`} 
                  alt={product.name}
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Product Info & Reviews */}
              <div className="flex w-full md:w-1/2 flex-col p-8 md:p-10">
                <div className="mb-6">
                  <span className="mb-2 inline-block rounded-full bg-indigo-50 px-3 py-1 text-xs font-bold text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                    {product.category}
                  </span>
                  <h2 className="text-3xl font-black text-gray-900 dark:text-white">{product.name}</h2>
                  <div className="mt-2 flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star 
                            key={star} 
                            size={14} 
                            fill={star <= Math.round(product.averageRating || 0) ? "currentColor" : "none"} 
                            className={star <= Math.round(product.averageRating || 0) ? "text-amber-500" : "text-gray-300 dark:text-gray-700"}
                          />
                        ))}
                      </div>
                      <span className="font-bold text-amber-500">{product.averageRating?.toFixed(1) || 'No ratings'}</span>
                      {product.ratingCount && product.ratingCount > 0 && (
                        <span className="text-sm text-gray-400 dark:text-gray-500">({product.ratingCount} reviews)</span>
                      )}
                    </div>
                    <span className="text-2xl font-black text-indigo-600 dark:text-indigo-400">${currentPrice}</span>
                  </div>
                </div>

                {product.variants && product.variants.length > 0 && (
                  <div className="mb-8">
                    <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-gray-400">Select Variant</h3>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <button
                        onClick={() => setSelectedVariant(null)}
                        className={cn(
                          "flex items-center justify-between rounded-2xl border-2 p-4 transition-all",
                          !selectedVariant 
                            ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20" 
                            : "border-gray-100 hover:border-indigo-200 dark:border-gray-800 dark:hover:border-indigo-900/50"
                        )}
                      >
                        <div className="text-left">
                          <p className="text-sm font-bold text-gray-900 dark:text-white">Standard</p>
                          <p className="text-xs text-gray-500">Base version</p>
                        </div>
                        <p className="font-black text-indigo-600 dark:text-indigo-400">${product.price}</p>
                      </button>
                      {product.variants.map(variant => (
                        <button
                          key={variant.id}
                          onClick={() => setSelectedVariant(variant)}
                          className={cn(
                            "flex items-center justify-between rounded-2xl border-2 p-4 transition-all",
                            selectedVariant?.id === variant.id 
                              ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20" 
                              : "border-gray-100 hover:border-indigo-200 dark:border-gray-800 dark:hover:border-indigo-900/50"
                          )}
                        >
                          <div className="text-left">
                            <p className="text-sm font-bold text-gray-900 dark:text-white">{variant.name}</p>
                            <p className="text-xs text-gray-500">Variant</p>
                          </div>
                          <p className="font-black text-indigo-600 dark:text-indigo-400">${variant.price}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                  <div className="mb-8">
                  <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-gray-400">Description</h3>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">{product.description}</p>
                </div>

                {product.tags && product.tags.length > 0 && (
                  <div className="mb-8">
                    <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-gray-400">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {product.tags.map(tag => (
                        <span key={tag} className="rounded-lg bg-gray-100 px-3 py-1 text-xs font-medium text-gray-600 dark:bg-gray-800 dark:text-gray-400">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="mb-8 flex items-center gap-3 rounded-2xl bg-gray-50 p-4 dark:bg-gray-800/50">
                  <div className="relative">
                    <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center font-bold text-indigo-600 dark:bg-indigo-900 dark:text-indigo-300">
                      {product.sellerName.charAt(0)}
                    </div>
                    {product.sellerStatus === 'approved' && (
                      <div className="absolute -bottom-1 -right-1 rounded-full bg-white p-0.5 dark:bg-gray-900">
                        <CheckCircle2 size={14} className="text-green-500 fill-green-500/10" />
                      </div>
                    )}
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Sold by</p>
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-bold text-gray-900 dark:text-white">{product.sellerName}</p>
                      {product.sellerStatus === 'approved' && (
                        <span className="flex items-center gap-0.5 rounded-full bg-green-100 px-2 py-0.5 text-[10px] font-bold text-green-600 dark:bg-green-900/30 dark:text-green-400">
                          <CheckCircle2 size={10} />
                          Verified
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {!hasPurchased && product.sellerId !== auth.currentUser?.uid && (
                  <button 
                    onClick={() => onBuy(product, selectedVariant || undefined)}
                    className="mb-10 flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95 dark:shadow-none"
                  >
                    <ShoppingBag size={20} />
                    Buy Now for ${currentPrice}
                  </button>
                )}

                {hasPurchased && (
                  <a 
                    href={product.downloadUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mb-10 flex w-full items-center justify-center gap-2 rounded-2xl bg-green-600 py-4 font-bold text-white shadow-xl shadow-green-100 hover:bg-green-700 transition-all active:scale-95 dark:shadow-none"
                  >
                    <Download size={20} />
                    Download Asset
                  </a>
                )}

                {/* Reviews Section */}
                <div className="space-y-8 border-t border-gray-100 pt-8 dark:border-gray-800">
                  <h3 className="text-xl font-black text-gray-900 dark:text-white">Reviews</h3>
                  
                  {hasPurchased && !userHasReviewed && (
                    <ReviewForm productId={product.id} onSubmit={(rating, comment) => onAddReview(product.id, rating, comment)} />
                  )}

                  <div className="space-y-6">
                    {productReviews.length > 0 ? (
                      productReviews.map(review => (
                        <div key={review.id} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="h-8 w-8 rounded-full bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-600 dark:bg-gray-800 dark:text-gray-400">
                                {review.userName.charAt(0)}
                              </div>
                              <p className="text-sm font-bold text-gray-900 dark:text-white">{review.userName}</p>
                            </div>
                            <div className="flex items-center gap-0.5 text-amber-500">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} size={12} fill={i < review.rating ? "currentColor" : "none"} className={i < review.rating ? "" : "text-gray-200 dark:text-gray-700"} />
                              ))}
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{review.comment}</p>
                          <p className="text-[10px] text-gray-400">
                            {new Date(review.createdAt?.toDate()).toLocaleDateString()}
                          </p>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-sm text-gray-500 dark:text-gray-400 py-4">No reviews yet.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const SuccessModal = ({ 
  isOpen, 
  onClose, 
  onViewPurchases,
  productName 
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onViewPurchases: () => void;
  productName: string 
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-sm rounded-3xl bg-white p-8 text-center shadow-2xl dark:bg-gray-900 dark:shadow-none"
          >
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
              <CheckCircle2 size={48} />
            </div>
            <h2 className="mb-2 text-2xl font-bold text-gray-900 dark:text-white">Purchase Successful!</h2>
            <p className="mb-6 text-gray-500 dark:text-gray-400">
              You've successfully purchased <strong>{productName}</strong>. You can now download it from your purchases.
            </p>
            <div className="flex flex-col gap-3">
              <button 
                onClick={onClose}
                className="w-full rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all dark:shadow-none"
              >
                Great!
              </button>
              <button 
                onClick={() => {
                  onClose();
                  onViewPurchases();
                }}
                className="w-full rounded-2xl bg-gray-100 py-4 font-bold text-gray-900 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-white dark:hover:bg-gray-700"
              >
                View My Purchases
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const DeleteConfirmationModal = ({ 
  isOpen, 
  onClose, 
  onConfirm,
  title,
  message
}: { 
  isOpen: boolean; 
  onClose: () => void; 
  onConfirm: () => void;
  title: string;
  message: string;
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          />
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="relative w-full max-w-sm rounded-3xl bg-white p-8 text-center shadow-2xl dark:bg-gray-900 dark:shadow-none"
          >
            <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400">
              <Trash2 size={48} />
            </div>
            <h2 className="mb-2 text-2xl font-bold text-gray-900 dark:text-white">{title}</h2>
            <p className="mb-6 text-gray-500 dark:text-gray-400">
              {message}
            </p>
            <div className="flex gap-4">
              <button 
                onClick={onClose}
                className="flex-1 rounded-2xl bg-gray-100 py-4 font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  onConfirm();
                  onClose();
                }}
                className="flex-1 rounded-2xl bg-red-600 py-4 font-bold text-white shadow-lg shadow-red-100 hover:bg-red-700 transition-all dark:shadow-none"
              >
                Delete
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

const ProfileView = ({ 
  userProfile, 
  onUpdate,
  stats,
  myProducts
}: { 
  userProfile: UserProfile | null; 
  onUpdate: (displayName: string, photoURL: string, bio: string, location: string, website: string, twitter: string, github: string, linkedin: string) => Promise<void>;
  stats: {
    purchases: number;
    products: number;
    sales: number;
  };
  myProducts: Product[];
}) => {
  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [photoURL, setPhotoURL] = useState(userProfile?.photoURL || '');
  const [bio, setBio] = useState(userProfile?.bio || '');
  const [location, setLocation] = useState(userProfile?.location || '');
  const [website, setWebsite] = useState(userProfile?.website || '');
  const [twitter, setTwitter] = useState(userProfile?.twitter || '');
  const [github, setGithub] = useState(userProfile?.github || '');
  const [linkedin, setLinkedin] = useState(userProfile?.linkedin || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    if (userProfile) {
      setDisplayName(userProfile.displayName || '');
      setPhotoURL(userProfile.photoURL || '');
      setBio(userProfile.bio || '');
      setLocation(userProfile.location || '');
      setWebsite(userProfile.website || '');
      setTwitter(userProfile.twitter || '');
      setGithub(userProfile.github || '');
      setLinkedin(userProfile.linkedin || '');
    }
  }, [userProfile]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdating(true);
    setMessage(null);
    try {
      await onUpdate(displayName, photoURL, bio, location, website, twitter, github, linkedin);
      setMessage({ type: 'success', text: 'Profile updated successfully!' });
    } catch (err) {
      setMessage({ type: 'error', text: 'Failed to update profile.' });
    } finally {
      setIsUpdating(false);
    }
  };

  const joinedDate = userProfile?.createdAt?.toDate() 
    ? new Date(userProfile.createdAt.toDate()).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    : 'Recently';

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto max-w-4xl space-y-8"
    >
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* Left Column: Profile Summary & Stats */}
        <div className="space-y-8 lg:col-span-1">
          <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
            <div className="flex flex-col items-center text-center">
              <div className="relative mb-4">
                <img 
                  src={photoURL || `https://ui-avatars.com/api/?name=${displayName || 'User'}`} 
                  alt="Profile" 
                  className="h-32 w-32 rounded-full border-4 border-indigo-50 object-cover shadow-lg dark:border-indigo-900/30"
                />
                <div className={cn(
                  "absolute bottom-1 right-1 h-6 w-6 rounded-full border-4 border-white bg-green-500 dark:border-gray-900",
                  userProfile?.role === 'admin' ? "bg-indigo-500" : "bg-green-500"
                )} />
              </div>
              <h3 className="text-xl font-black text-gray-900 dark:text-white">{displayName || 'Anonymous User'}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{userProfile?.email}</p>
              
              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {userProfile?.role === 'admin' ? (
                  <div className="flex items-center gap-2 rounded-full bg-indigo-50 px-4 py-1 text-xs font-bold text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                    <Shield size={14} />
                    Administrator
                  </div>
                ) : (
                  <div className="flex items-center gap-2 rounded-full bg-gray-50 px-4 py-1 text-xs font-bold text-gray-600 dark:bg-gray-800 dark:text-gray-400">
                    <User size={14} />
                    Member
                  </div>
                )}
                {userProfile?.sellerStatus === 'approved' && (
                  <div className="flex items-center gap-2 rounded-full bg-green-50 px-4 py-1 text-xs font-bold text-green-600 dark:bg-green-900/30 dark:text-green-400">
                    <CheckCircle2 size={14} />
                    Verified Seller
                  </div>
                )}
                {userProfile?.sellerStatus === 'pending' && (
                  <div className="flex items-center gap-2 rounded-full bg-amber-50 px-4 py-1 text-xs font-bold text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                    <Loader2 size={14} className="animate-spin" />
                    Verification Pending
                  </div>
                )}
              </div>

              <div className="mt-8 w-full space-y-4 border-t border-gray-50 pt-8 dark:border-gray-800">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Joined</span>
                  <span className="text-sm font-bold text-gray-900 dark:text-white">{joinedDate}</span>
                </div>
                {location && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500 dark:text-gray-400">Location</span>
                    <div className="flex items-center gap-1 text-sm font-bold text-gray-900 dark:text-white">
                      <MapPin size={14} className="text-gray-400" />
                      {location}
                    </div>
                  </div>
                )}
              </div>

              {bio && (
                <div className="mt-6 w-full border-t border-gray-50 pt-6 text-left dark:border-gray-800">
                  <p className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-2">Bio</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">{bio}</p>
                </div>
              )}

              {(website || twitter || github || linkedin) && (
                <div className="mt-6 w-full border-t border-gray-50 pt-6 dark:border-gray-800">
                  <p className="text-xs font-bold uppercase tracking-wider text-gray-400 mb-3 text-left">Social Links</p>
                  <div className="flex flex-wrap gap-3">
                    {website && (
                      <a href={website.startsWith('http') ? website : `https://${website}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-10 w-10 rounded-xl bg-gray-50 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-indigo-900/30 dark:hover:text-indigo-400" title="Website">
                        <Globe size={18} />
                      </a>
                    )}
                    {twitter && (
                      <a href={`https://twitter.com/${twitter.replace('@', '')}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-10 w-10 rounded-xl bg-gray-50 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-indigo-900/30 dark:hover:text-indigo-400" title="Twitter">
                        <Twitter size={18} />
                      </a>
                    )}
                    {github && (
                      <a href={`https://github.com/${github}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-10 w-10 rounded-xl bg-gray-50 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-indigo-900/30 dark:hover:text-indigo-400" title="GitHub">
                        <Github size={18} />
                      </a>
                    )}
                    {linkedin && (
                      <a href={linkedin.startsWith('http') ? linkedin : `https://linkedin.com/in/${linkedin}`} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-10 w-10 rounded-xl bg-gray-50 text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-indigo-900/30 dark:hover:text-indigo-400" title="LinkedIn">
                        <Linkedin size={18} />
                      </a>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 gap-4">
            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Purchases</p>
              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">{stats.purchases}</p>
            </div>
            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Products Listed</p>
              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">{stats.products}</p>
            </div>
            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
              <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Total Sales</p>
              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">{stats.sales}</p>
            </div>
          </div>

          {/* User's Products List in Profile */}
          {myProducts.length > 0 && (
            <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
              <h3 className="mb-6 text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
                <Package className="text-indigo-600" size={24} />
                Your Products
              </h3>
              <div className="space-y-4">
                {myProducts.map(p => (
                  <div key={p.id} className="flex items-center justify-between rounded-2xl border border-gray-50 p-4 dark:border-gray-800">
                    <div className="flex items-center gap-3">
                      <img src={p.imageUrl || `https://picsum.photos/seed/${p.id}/100/100`} className="h-12 w-12 rounded-xl object-cover" alt="" />
                      <div>
                        <p className="text-sm font-bold text-gray-900 dark:text-white">{p.name}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">${p.price}</p>
                      </div>
                    </div>
                    <span className="rounded-full bg-indigo-50 px-3 py-1 text-[10px] font-bold text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                      {p.category}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Edit Form */}
        <div className="lg:col-span-2">
          <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
            <h2 className="mb-8 text-2xl font-black text-gray-900 dark:text-white">Edit Profile</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Display Name</label>
                  <input 
                    type="text" 
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="Your name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Location</label>
                  <input 
                    type="text" 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="City, Country"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Bio</label>
                <textarea 
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  rows={4}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="Tell us about yourself..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Profile Picture URL</label>
                <input 
                  type="url" 
                  value={photoURL}
                  onChange={(e) => setPhotoURL(e.target.value)}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="https://example.com/photo.jpg"
                />
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Website</label>
                  <input 
                    type="url" 
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="https://yourwebsite.com"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Twitter (X)</label>
                  <input 
                    type="text" 
                    value={twitter}
                    onChange={(e) => setTwitter(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="@username"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">GitHub</label>
                  <input 
                    type="text" 
                    value={github}
                    onChange={(e) => setGithub(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="username"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">LinkedIn</label>
                  <input 
                    type="text" 
                    value={linkedin}
                    onChange={(e) => setLinkedin(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="username"
                  />
                </div>
              </div>

              {message && (
                <div className={cn(
                  "rounded-2xl p-4 text-sm font-medium",
                  message.type === 'success' ? "bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400" : "bg-red-50 text-red-700 dark:bg-red-900/20 dark:text-red-400"
                )}>
                  {message.text}
                </div>
              )}

              <button 
                type="submit"
                disabled={isUpdating}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 dark:shadow-none"
              >
                {isUpdating ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    Updating...
                  </>
                ) : (
                  'Save Changes'
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const BecomeSellerForm = ({ onSubmit }: { onSubmit: (details: { 
  bio: string; 
  website: string; 
  twitter: string; 
  location: string;
  verification: {
    fullName: string;
    idType: string;
    idNumber: string;
    expertise: string;
  }
}) => void }) => {
  const [step, setStep] = useState(1);
  const [bio, setBio] = useState('');
  const [website, setWebsite] = useState('');
  const [twitter, setTwitter] = useState('');
  const [location, setLocation] = useState('');
  const [fullName, setFullName] = useState('');
  const [idType, setIdType] = useState('ID Card');
  const [idNumber, setIdNumber] = useState('');
  const [expertise, setExpertise] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const totalSteps = 5;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      await onSubmit({ 
        bio, 
        website, 
        twitter, 
        location,
        verification: {
          fullName,
          idType,
          idNumber,
          expertise
        }
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextStep = () => setStep(prev => Math.min(prev + 1, totalSteps));
  const prevStep = () => setStep(prev => Math.max(prev - 1, 1));

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="text-center">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white">Why Sell on DigiCart?</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Join thousands of creators and start earning today.</p>
            </div>
            
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
              <div className="rounded-2xl border border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                  <DollarSign size={24} />
                </div>
                <h4 className="font-bold text-gray-900 dark:text-white">Low Fees</h4>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Keep more of what you earn with our industry-leading low commission rates.</p>
              </div>
              
              <div className="rounded-2xl border border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                  <Globe size={24} />
                </div>
                <h4 className="font-bold text-gray-900 dark:text-white">Global Reach</h4>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Sell your digital assets to customers all over the world instantly.</p>
              </div>
              
              <div className="rounded-2xl border border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                  <TrendingUp size={24} />
                </div>
                <h4 className="font-bold text-gray-900 dark:text-white">Powerful Analytics</h4>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Track your sales, revenue, and customer behavior with detailed insights.</p>
              </div>
              
              <div className="rounded-2xl border border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400">
                  <CheckCircle2 size={24} />
                </div>
                <h4 className="font-bold text-gray-900 dark:text-white">Instant Payouts</h4>
                <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Request your earnings anytime and get paid directly to your account.</p>
              </div>
            </div>
            
            <button 
              onClick={nextStep}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 dark:shadow-none"
            >
              Get Started
              <ChevronRight size={20} />
            </button>
          </motion.div>
        );
      case 2:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="text-center">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white">Seller Requirements</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Just a few things to keep in mind before you start.</p>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start gap-4 rounded-2xl border border-gray-100 bg-gray-50 p-5 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mt-1 text-indigo-600 dark:text-indigo-400">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 dark:text-white">Original Content</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">You must own the rights to all digital assets you list on the marketplace.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 rounded-2xl border border-gray-100 bg-gray-50 p-5 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mt-1 text-indigo-600 dark:text-indigo-400">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 dark:text-white">Quality Standards</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Products should be well-documented and provide value to the customers.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 rounded-2xl border border-gray-100 bg-gray-50 p-5 dark:border-gray-800 dark:bg-gray-800/50">
                <div className="mt-1 text-indigo-600 dark:text-indigo-400">
                  <CheckCircle2 size={20} />
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 dark:text-white">Accurate Descriptions</h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Provide clear and honest descriptions for all your listings.</p>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={prevStep}
                className="flex-1 rounded-2xl bg-gray-100 py-4 font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
              >
                Back
              </button>
              <button 
                onClick={nextStep}
                className="flex-[2] rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 dark:shadow-none"
              >
                I Understand
              </button>
            </div>
          </motion.div>
        );
      case 3:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="text-center">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white">Setup Your Profile</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Tell your customers a bit about yourself.</p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Bio / About You</label>
                <textarea 
                  required
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="Tell us about yourself and what you sell..."
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Website</label>
                  <input 
                    type="url"
                    value={website}
                    onChange={(e) => setWebsite(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="https://yourwebsite.com"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Twitter (X)</label>
                  <input 
                    type="text"
                    value={twitter}
                    onChange={(e) => setTwitter(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="@username"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Location</label>
                <input 
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="City, Country"
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={prevStep}
                className="flex-1 rounded-2xl bg-gray-100 py-4 font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
              >
                Back
              </button>
              <button 
                onClick={nextStep}
                disabled={!bio.trim()}
                className="flex-[2] rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 dark:shadow-none"
              >
                Continue
              </button>
            </div>
          </motion.div>
        );
      case 4:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-6"
          >
            <div className="text-center">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white">Seller Verification</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Help us build trust by verifying your identity.</p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Full Legal Name</label>
                <input 
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="As it appears on your ID"
                />
              </div>

              <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">ID Document Type</label>
                  <select 
                    value={idType}
                    onChange={(e) => setIdType(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  >
                    <option>ID Card</option>
                    <option>Passport</option>
                    <option>Driver's License</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">ID Document Number</label>
                  <input 
                    type="text"
                    required
                    value={idNumber}
                    onChange={(e) => setIdNumber(e.target.value)}
                    className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                    placeholder="Enter ID number"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Experience & Expertise</label>
                <textarea 
                  required
                  value={expertise}
                  onChange={(e) => setExpertise(e.target.value)}
                  className="w-full rounded-2xl border border-gray-100 bg-gray-50 px-5 py-4 text-gray-900 focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                  placeholder="Briefly describe your experience with the digital assets you plan to sell..."
                  rows={3}
                />
              </div>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={prevStep}
                className="flex-1 rounded-2xl bg-gray-100 py-4 font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
              >
                Back
              </button>
              <button 
                onClick={nextStep}
                disabled={!fullName.trim() || !idNumber.trim() || !expertise.trim()}
                className="flex-[2] rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 dark:shadow-none"
              >
                Continue
              </button>
            </div>
          </motion.div>
        );
      case 5:
        return (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="space-y-8"
          >
            <div className="text-center">
              <h3 className="text-2xl font-black text-gray-900 dark:text-white">Final Review</h3>
              <p className="mt-2 text-gray-500 dark:text-gray-400">Everything looks good! Ready to open your shop?</p>
            </div>
            
            <div className="rounded-2xl border border-gray-100 bg-gray-50 p-6 dark:border-gray-800 dark:bg-gray-800/50">
              <div className="space-y-4">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Bio</p>
                  <p className="text-sm text-gray-900 dark:text-white">{bio}</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Website</p>
                    <p className="text-sm text-gray-900 dark:text-white">{website || 'Not provided'}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Location</p>
                    <p className="text-sm text-gray-900 dark:text-white">{location || 'Not provided'}</p>
                  </div>
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-gray-400">Verification</p>
                  <p className="text-sm text-gray-900 dark:text-white">{fullName} ({idType})</p>
                </div>
              </div>
            </div>
            
            <div className="flex gap-4">
              <button 
                onClick={prevStep}
                className="flex-1 rounded-2xl bg-gray-100 py-4 font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
              >
                Edit
              </button>
              <button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="flex-[2] flex items-center justify-center gap-2 rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 dark:shadow-none"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="animate-spin" size={20} />
                    Setting up...
                  </>
                ) : (
                  <>
                    <CheckCircle2 size={20} />
                    Complete Setup
                  </>
                )}
              </button>
            </div>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="mx-auto max-w-2xl rounded-[2.5rem] border border-gray-100 bg-white p-10 shadow-2xl dark:border-gray-800 dark:bg-gray-900">
      <div className="mb-10">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-100 dark:shadow-none">
            <Store size={24} />
          </div>
          <div className="flex gap-1.5">
            {[...Array(totalSteps)].map((_, i) => (
              <div 
                key={i} 
                className={cn(
                  "h-1.5 w-8 rounded-full transition-all duration-500",
                  step > i ? "bg-indigo-600" : "bg-gray-100 dark:bg-gray-800"
                )}
              />
            ))}
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm font-bold text-indigo-600 dark:text-indigo-400">
          <span>Step {step} of {totalSteps}</span>
          <span className="h-1 w-1 rounded-full bg-indigo-600/30" />
          <span className="text-gray-400">
            {step === 1 && "Benefits"}
            {step === 2 && "Requirements"}
            {step === 3 && "Profile Setup"}
            {step === 4 && "Review"}
          </span>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {renderStep()}
      </AnimatePresence>
    </div>
  );
};

export default function App() {
  const [user, loading, error] = useAuthState(auth);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [view, setView] = useState<View>('marketplace');
  const [adminTab, setAdminTab] = useState<'users' | 'products' | 'sellers' | 'payouts'>('users');
  const [sellerDashboardTab, setSellerDashboardTab] = useState<'overview' | 'products' | 'sales' | 'payouts'>('overview');
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [adminSearchQuery, setAdminSearchQuery] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [myPurchases, setMyPurchases] = useState<Order[]>([]);
  const [sellerOrders, setSellerOrders] = useState<Order[]>([]);
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [productVariants, setProductVariants] = useState<ProductVariant[]>([]);
  const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [purchasedProductName, setPurchasedProductName] = useState('');
  const [sortOption, setSortOption] = useState<SortOption>('newest');

  // Memoized sales trend data for the last 7 days
  const salesTrendData = React.useMemo(() => {
    return Array.from({ length: 7 }).map((_, i) => {
      const date = subDays(new Date(), 6 - i);
      const daySales = sellerOrders.filter(o => 
        o.createdAt && isSameDay(o.createdAt.toDate(), date)
      );
      return {
        name: format(date, 'MMM dd'),
        revenue: daySales.reduce((acc, o) => acc + o.price, 0),
        sales: daySales.length
      };
    });
  }, [sellerOrders]);

  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('darkMode') === 'true' || 
             (!localStorage.getItem('darkMode') && window.matchMedia('(prefers-color-scheme: dark)').matches);
    }
    return false;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('darkMode', isDarkMode.toString());
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  const categories = ['All', 'Software', 'E-books', 'Graphics', 'Music', 'Courses', 'Templates'];

  // --- Sync User Profile ---
  useEffect(() => {
    if (user) {
      const userRef = doc(db, 'users', user.uid);
      const unsubscribe = onSnapshot(userRef, (snap) => {
        if (snap.exists()) {
          setUserProfile({ uid: snap.id, ...snap.data() } as UserProfile);
        } else {
          setDoc(userRef, {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: user.photoURL,
            role: 'user',
            sellerStatus: 'none',
            createdAt: serverTimestamp()
          });
        }
      });
      return () => unsubscribe();
    } else {
      setUserProfile(null);
    }
  }, [user]);

  const handleBecomeSeller = async (details: { 
    bio: string; 
    website: string; 
    twitter: string; 
    location: string;
    verification: {
      fullName: string;
      idType: string;
      idNumber: string;
      expertise: string;
    }
  }) => {
    if (!user) return;
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        ...details,
        sellerStatus: 'approved',
        'verification.verifiedAt': serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'users');
    }
  };

  // --- Fetch All Users (Admin Only) ---
  useEffect(() => {
    if (userProfile?.role === 'admin') {
      const q = query(collection(db, 'users'), orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const u = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
        setAllUsers(u);
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'users'));
      return () => unsubscribe();
    }
  }, [userProfile]);

  // --- Fetch Products ---
  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const p = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
      setProducts(p);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'products'));
    return () => unsubscribe();
  }, []);

  // --- Fetch Payout Requests ---
  useEffect(() => {
    if (!user) {
      setPayoutRequests([]);
      return;
    }

    let q;
    if (userProfile?.role === 'admin') {
      q = query(collection(db, 'payoutRequests'), orderBy('createdAt', 'desc'));
    } else {
      q = query(collection(db, 'payoutRequests'), where('sellerId', '==', user.uid), orderBy('createdAt', 'desc'));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const p = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PayoutRequest));
      setPayoutRequests(p);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'payoutRequests'));
    return () => unsubscribe();
  }, [user, userProfile]);

  const handleRequestPayout = async (amount: number) => {
    if (!user || !userProfile) return;
    if (amount <= 0 || amount > (userProfile.balance || 0)) {
      alert('Invalid payout amount.');
      return;
    }

    try {
      const payoutData = {
        sellerId: user.uid,
        sellerName: userProfile.displayName,
        amount,
        status: 'pending',
        createdAt: serverTimestamp()
      };
      await addDoc(collection(db, 'payoutRequests'), payoutData);

      // Deduct from balance immediately (or mark as pending balance)
      // For simplicity, let's deduct it now.
      await updateDoc(doc(db, 'users', user.uid), {
        balance: (userProfile.balance || 0) - amount
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'payoutRequests');
    }
  };

  const handleApprovePayout = async (payoutId: string) => {
    if (userProfile?.role !== 'admin') return;
    try {
      await updateDoc(doc(db, 'payoutRequests', payoutId), {
        status: 'approved',
        processedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'payoutRequests');
    }
  };

  const handleRejectPayout = async (payoutId: string, amount: number, sellerId: string) => {
    if (userProfile?.role !== 'admin') return;
    try {
      await updateDoc(doc(db, 'payoutRequests', payoutId), {
        status: 'rejected',
        processedAt: serverTimestamp()
      });

      // Refund balance
      const sellerRef = doc(db, 'users', sellerId);
      const sellerSnap = await getDoc(sellerRef);
      if (sellerSnap.exists()) {
        const sellerData = sellerSnap.data() as UserProfile;
        await updateDoc(sellerRef, {
          balance: (sellerData.balance || 0) + amount
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'payoutRequests');
    }
  };
  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'orders'), 
        where('buyerId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const o = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setMyPurchases(o);
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'orders'));
      return () => unsubscribe();
    }
  }, [user]);

  // --- Fetch Seller Orders ---
  useEffect(() => {
    if (user && userProfile?.sellerStatus === 'approved') {
      const q = query(
        collection(db, 'orders'), 
        where('sellerId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const o = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setSellerOrders(o);
      }, (err) => handleFirestoreError(err, OperationType.LIST, 'orders'));
      return () => unsubscribe();
    } else {
      setSellerOrders([]);
    }
  }, [user, userProfile?.sellerStatus]);

  // --- Fetch Reviews ---
  useEffect(() => {
    const q = query(collection(db, 'reviews'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const r = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Review));
      setReviews(r);
    }, (err) => handleFirestoreError(err, OperationType.LIST, 'reviews'));
    return () => unsubscribe();
  }, []);

  const handleToggleAdmin = async (targetUser: UserProfile) => {
    if (targetUser.uid === user?.uid) return;
    const newRole = targetUser.role === 'admin' ? 'user' : 'admin';
    try {
      await updateDoc(doc(db, 'users', targetUser.uid), { role: newRole });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'users');
    }
  };

  const handleBuy = async (product: Product, variant?: ProductVariant) => {
    if (!user) {
      signInWithGoogle();
      return;
    }

    try {
      const price = variant ? variant.price : product.price;
      const productName = variant ? `${product.name} (${variant.name})` : product.name;
      const orderId = `${user.uid}_${product.id}${variant ? `_${variant.id}` : ''}`;
      
      await setDoc(doc(db, 'orders', orderId), {
        buyerId: user.uid,
        sellerId: product.sellerId,
        productId: product.id,
        variantId: variant?.id || null,
        productName,
        price,
        status: 'completed',
        createdAt: serverTimestamp()
      });

      // Increment salesCount
      await updateDoc(doc(db, 'products', product.id), {
        salesCount: (product.salesCount || 0) + 1
      });

      // Increment seller balance
      const sellerRef = doc(db, 'users', product.sellerId);
      const sellerSnap = await getDoc(sellerRef);
      if (sellerSnap.exists()) {
        const sellerData = sellerSnap.data() as UserProfile;
        await updateDoc(sellerRef, {
          balance: (sellerData.balance || 0) + price
        });
      }

      setPurchasedProductName(productName);
      setIsSuccessModalOpen(true);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'orders');
    }
  };

  const handleUpdateProfile = async (displayName: string, photoURL: string, bio: string, location: string, website: string, twitter: string, github: string, linkedin: string) => {
    if (!user || !userProfile) return;

    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        displayName,
        photoURL,
        bio,
        location,
        website,
        twitter,
        github,
        linkedin,
        updatedAt: serverTimestamp()
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'users');
      throw err;
    }
  };

  const handleBulkUpload = async (file: File) => {
    if (!user) return;
    setIsGeneratingImage(true); // Reusing this for loading state
    
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (results) => {
        const productsToUpload = results.data as any[];
        let successCount = 0;
        let errorCount = 0;

        for (const p of productsToUpload) {
          try {
            const name = p.name || p.Name;
            const category = p.category || p.Category || 'Software';
            const subCategory = p.subCategory || p.SubCategory || '';
            const tags = p.tags || p.Tags ? (p.tags || p.Tags).split(',').map((t: string) => t.trim()).filter(Boolean) : [];
            const price = parseFloat(p.price || p.Price || '0');
            const description = p.description || p.Description || '';
            const downloadUrl = p.downloadUrl || p.DownloadUrl || '';
            let imageUrl = p.imageUrl || p.ImageUrl || '';
            let isAiGenerated = false;

            if (!name || !downloadUrl) {
              errorCount++;
              continue;
            }

            if (!imageUrl) {
              const generated = await generateProductImage(name, category);
              if (generated) {
                imageUrl = generated;
                isAiGenerated = true;
              }
            }

            const productData = {
              name,
              description,
              price,
              category,
              subCategory,
              tags,
              downloadUrl,
              imageUrl,
              isAiGenerated,
              sellerId: user.uid,
              sellerName: user.displayName || 'Anonymous',
              sellerStatus: userProfile?.sellerStatus || 'none',
              salesCount: 0,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp()
            };

            await addDoc(collection(db, 'products'), productData);
            successCount++;
          } catch (err) {
            console.error('Error uploading product:', err);
            errorCount++;
          }
        }

        setIsGeneratingImage(false);
        setIsAddingProduct(false);
        alert(`Bulk upload complete! Success: ${successCount}, Errors: ${errorCount}`);
      },
      error: (err) => {
        console.error('CSV Parsing Error:', err);
        setIsGeneratingImage(false);
        alert('Error parsing CSV file.');
      }
    });
  };

  const handleAddProduct = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;

    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const category = formData.get('category') as string;
    const subCategory = formData.get('subCategory') as string;
    const tagsString = formData.get('tags') as string;
    const tags = tagsString ? tagsString.split(',').map(t => t.trim()).filter(Boolean) : [];
    let imageUrl = formData.get('imageUrl') as string;
    let isAiGenerated = false;

    setIsGeneratingImage(true);
    if (!imageUrl) {
      const generated = await generateProductImage(name, category);
      if (generated) {
        imageUrl = generated;
        isAiGenerated = true;
      }
    }

    const productData = {
      name,
      description: formData.get('description') as string,
      price: parseFloat(formData.get('price') as string),
      category,
      subCategory,
      tags,
      downloadUrl: formData.get('downloadUrl') as string,
      imageUrl,
      isAiGenerated,
      sellerId: user.uid,
      sellerName: user.displayName || 'Anonymous',
      sellerStatus: userProfile?.sellerStatus || 'none',
      variants: productVariants,
      salesCount: editingProduct ? (editingProduct.salesCount || 0) : 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    try {
      if (editingProduct) {
        await updateDoc(doc(db, 'products', editingProduct.id), {
          ...productData,
          updatedAt: serverTimestamp()
        });
      } else {
        await addDoc(collection(db, 'products'), productData);
      }
      setIsAddingProduct(false);
      setEditingProduct(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'products');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleDeleteProduct = async (product: Product) => {
    setProductToDelete(product);
  };

  const confirmDeleteProduct = async () => {
    if (!productToDelete) return;
    try {
      await deleteDoc(doc(db, 'products', productToDelete.id));
      setProductToDelete(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'products');
    }
  };

  const handleAddReview = async (productId: string, rating: number, comment: string) => {
    if (!user || !userProfile) return;
    try {
      // Use a unique ID for review to prevent multiple reviews per user per product if needed
      // For now, let's just use addDoc
      const reviewData = {
        userId: user.uid,
        userName: userProfile.displayName,
        productId,
        rating,
        comment,
        createdAt: serverTimestamp()
      };
      await addDoc(collection(db, 'reviews'), reviewData);

      // Update product rating
      const productRef = doc(db, 'products', productId);
      const productSnap = await getDoc(productRef);
      if (productSnap.exists()) {
        const productData = productSnap.data() as Product;
        const currentRatingCount = productData.ratingCount || 0;
        const currentAverageRating = productData.averageRating || 0;
        const newRatingCount = currentRatingCount + 1;
        const newAverageRating = ((currentAverageRating * currentRatingCount) + rating) / newRatingCount;

        await updateDoc(productRef, {
          ratingCount: newRatingCount,
          averageRating: newAverageRating
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'reviews');
      throw err;
    }
  };

  const filteredProducts = products
    .filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      if (sortOption === 'newest') {
        return b.createdAt?.toMillis?.() - a.createdAt?.toMillis?.();
      }
      if (sortOption === 'price-low') {
        return a.price - b.price;
      }
      if (sortOption === 'price-high') {
        return b.price - a.price;
      }
      if (sortOption === 'popularity') {
        return (b.salesCount || 0) - (a.salesCount || 0);
      }
      return 0;
    });

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-gray-50 dark:bg-gray-950">
        <Loader2 className="animate-spin text-indigo-600" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50/50 font-sans text-gray-900 transition-colors duration-300 dark:bg-gray-950 dark:text-gray-100">
      <Navbar 
        user={user} 
        userProfile={userProfile} 
        currentView={view} 
        setView={setView} 
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
      />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <AnimatePresence mode="wait">
          {view === 'marketplace' && (
            <motion.div 
              key="marketplace"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              {/* Hero Section */}
              <div className="mb-12 text-center">
                <h1 className="mb-4 text-4xl font-black tracking-tight text-gray-900 dark:text-white sm:text-6xl">
                  The Best <span className="text-indigo-600 dark:text-indigo-400">Digital Assets</span> Marketplace
                </h1>
                <p className="mx-auto max-w-2xl text-lg text-gray-500 dark:text-gray-400">
                  Discover high-quality software, e-books, graphics, and more from creators around the world.
                </p>
              </div>

              {/* Search & Filter */}
              <div className="mb-10 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="flex flex-1 flex-col gap-4 md:flex-row md:items-center">
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute top-1/2 left-4 -translate-y-1/2 text-gray-400" size={20} />
                    <input 
                      type="text" 
                      placeholder="Search products..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full rounded-2xl border border-gray-200 bg-white py-3 pl-12 pr-4 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="relative">
                    <ArrowUpDown className="absolute top-1/2 left-4 -translate-y-1/2 text-gray-400" size={18} />
                    <select
                      value={sortOption}
                      onChange={(e) => setSortOption(e.target.value as SortOption)}
                      className="w-full appearance-none rounded-2xl border border-gray-200 bg-white py-3 pl-12 pr-10 shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-900 dark:text-white dark:focus:ring-indigo-500/20"
                    >
                      <option value="newest">Newest First</option>
                      <option value="price-low">Price: Low to High</option>
                      <option value="price-high">Price: High to Low</option>
                      <option value="popularity">Most Popular</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-2 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={cn(
                        "whitespace-now800 px-5 py-2.5 rounded-xl text-sm font-bold transition-all active:scale-95",
                        selectedCategory === cat 
                          ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100 dark:shadow-none" 
                          : "bg-white text-gray-600 border border-gray-100 hover:border-indigo-200 dark:bg-gray-900 dark:text-gray-400 dark:border-gray-800 dark:hover:border-indigo-900"
                      )}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product Grid */}
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {filteredProducts.map(p => (
                    <ProductCard 
                      key={p.id} 
                      product={p} 
                      onBuy={handleBuy}
                      isOwner={user?.uid === p.sellerId}
                      onClick={setSelectedProduct}
                    />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <div className="mb-4 rounded-full bg-gray-100 p-6 text-gray-400 dark:bg-gray-900 dark:text-gray-600">
                    <Search size={48} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white">No products found</h3>
                  <p className="text-gray-500 dark:text-gray-400">Try adjusting your search or filters.</p>
                </div>
              )}
            </motion.div>
          )}

          {view === 'seller-dashboard' && user && (
            <motion.div 
              key="seller-dashboard"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex flex-col lg:flex-row gap-8"
            >
              {userProfile?.sellerStatus === 'approved' ? (
                <>
                  {/* Sidebar Navigation */}
                  <aside className="w-full lg:w-64 shrink-0">
                    <div className="sticky top-24 space-y-2">
                      <div className="mb-6 px-4">
                        <h2 className="text-2xl font-black text-gray-900 dark:text-white">Dashboard</h2>
                        <p className="text-xs text-gray-500 dark:text-gray-400">Seller Central</p>
                      </div>
                      
                      {[
                        { id: 'overview', label: 'Overview', icon: LayoutDashboard },
                        { id: 'products', label: 'My Products', icon: Package },
                        { id: 'sales', label: 'Sales History', icon: TrendingUp },
                        { id: 'payouts', label: 'Payouts', icon: Wallet },
                      ].map((tab) => (
                        <button
                          key={tab.id}
                          onClick={() => setSellerDashboardTab(tab.id as any)}
                          className={cn(
                            "flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold transition-all active:scale-95",
                            sellerDashboardTab === tab.id
                              ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100 dark:shadow-none"
                              : "text-gray-500 hover:bg-gray-100 dark:text-gray-400 dark:hover:bg-gray-800"
                          )}
                        >
                          <tab.icon size={18} />
                          {tab.label}
                        </button>
                      ))}

                      <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800">
                        <button 
                          onClick={() => {
                            setEditingProduct(null);
                            setProductVariants([]);
                            setIsAddingProduct(true);
                          }}
                          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-50 py-3 text-sm font-bold text-indigo-600 hover:bg-indigo-100 transition-all dark:bg-indigo-900/30 dark:text-indigo-400 dark:hover:bg-indigo-900/50"
                        >
                          <Plus size={18} />
                          New Listing
                        </button>
                      </div>
                    </div>
                  </aside>

                  {/* Main Content Area */}
                  <div className="flex-1 min-w-0">
                    <AnimatePresence mode="wait">
                      {sellerDashboardTab === 'overview' && (
                        <motion.div
                          key="overview"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="space-y-8"
                        >
                          <div className="flex items-center justify-between">
                            <h3 className="text-xl font-black text-gray-900 dark:text-white">Overview</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Real-time performance</p>
                          </div>

                          {/* Seller Stats */}
                          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 xl:grid-cols-4">
                            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                                <Package size={24} />
                              </div>
                              <p className="text-sm font-bold text-gray-500 dark:text-gray-400">Total Products</p>
                              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">
                                {products.filter(p => p.sellerId === user.uid).length}
                              </p>
                            </div>
                            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-green-50 text-green-600 dark:bg-green-900/30 dark:text-green-400">
                                <TrendingUp size={24} />
                              </div>
                              <p className="text-sm font-bold text-gray-500 dark:text-gray-400">Total Sales</p>
                              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">
                                {sellerOrders.length}
                              </p>
                            </div>
                            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400">
                                <DollarSign size={24} />
                              </div>
                              <p className="text-sm font-bold text-gray-500 dark:text-gray-400">Total Revenue</p>
                              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">
                                ${sellerOrders.reduce((acc, o) => acc + o.price, 0).toFixed(2)}
                              </p>
                            </div>
                            <div className="rounded-3xl border border-gray-100 bg-white p-6 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-50 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400">
                                <Star size={24} />
                              </div>
                              <p className="text-sm font-bold text-gray-500 dark:text-gray-400">Avg. Rating</p>
                              <p className="mt-1 text-2xl font-black text-gray-900 dark:text-white">
                                {(products.filter(p => p.sellerId === user.uid).reduce((acc, p) => acc + (p.averageRating || 0), 0) / (products.filter(p => p.sellerId === user.uid).length || 1)).toFixed(1)}
                              </p>
                            </div>
                          </div>

                          <div className="rounded-3xl border border-indigo-100 bg-indigo-50/30 p-8 shadow-sm dark:border-indigo-900/30 dark:bg-indigo-900/10">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                              <div className="flex items-center gap-4">
                                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-200 dark:shadow-none">
                                  <Wallet size={28} />
                                </div>
                                <div>
                                  <p className="text-sm font-bold text-indigo-600 dark:text-indigo-400">Available Balance</p>
                                  <p className="text-3xl font-black text-gray-900 dark:text-white">
                                    ${(userProfile?.balance || 0).toFixed(2)}
                                  </p>
                                </div>
                              </div>
                              <button 
                                onClick={() => {
                                  setPayoutAmount('');
                                  setIsPayoutModalOpen(true);
                                }}
                                disabled={(userProfile?.balance || 0) <= 0}
                                className="rounded-2xl bg-indigo-600 px-8 py-4 font-bold text-white shadow-xl shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 dark:shadow-none"
                              >
                                Withdraw Funds
                              </button>
                            </div>
                          </div>

                          {/* Sales Trend Chart */}
                          <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                            <div className="mb-6 flex items-center justify-between">
                              <h4 className="font-black text-gray-900 dark:text-white">Sales Trend (Last 7 Days)</h4>
                              <div className="flex items-center gap-4">
                                <div className="flex items-center gap-2">
                                  <div className="h-3 w-3 rounded-full bg-indigo-600"></div>
                                  <span className="text-xs font-bold text-gray-500 dark:text-gray-400">Revenue</span>
                                </div>
                                <div className="flex items-center gap-2">
                                  <div className="h-3 w-3 rounded-full bg-emerald-500"></div>
                                  <span className="text-xs font-bold text-gray-500 dark:text-gray-400">Sales</span>
                                </div>
                              </div>
                            </div>
                            <div className="h-[300px] w-full">
                              <ResponsiveContainer width="100%" height="100%">
                                <AreaChart
                                  data={salesTrendData}
                                  margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                                >
                                  <defs>
                                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                                    </linearGradient>
                                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                                  <XAxis 
                                    dataKey="name" 
                                    axisLine={false} 
                                    tickLine={false} 
                                    tick={{ fontSize: 12, fontWeight: 600, fill: '#9ca3af' }}
                                    dy={10}
                                  />
                                  <YAxis 
                                    yId="left"
                                    axisLine={false} 
                                    tickLine={false} 
                                    tick={{ fontSize: 12, fontWeight: 600, fill: '#9ca3af' }}
                                    tickFormatter={(value) => `$${value}`}
                                  />
                                  <YAxis 
                                    yId="right"
                                    orientation="right"
                                    axisLine={false} 
                                    tickLine={false} 
                                    tick={{ fontSize: 12, fontWeight: 600, fill: '#9ca3af' }}
                                  />
                                  <Tooltip 
                                    contentStyle={{ 
                                      borderRadius: '16px', 
                                      border: 'none', 
                                      boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                                      padding: '12px'
                                    }}
                                    itemStyle={{ fontWeight: 800 }}
                                    labelStyle={{ fontWeight: 800, marginBottom: '4px' }}
                                  />
                                  <Area 
                                    yId="left"
                                    type="monotone" 
                                    dataKey="revenue" 
                                    stroke="#4f46e5" 
                                    strokeWidth={4}
                                    fillOpacity={1} 
                                    fill="url(#colorRevenue)" 
                                  />
                                  <Area 
                                    yId="right"
                                    type="monotone" 
                                    dataKey="sales" 
                                    stroke="#10b981" 
                                    strokeWidth={4}
                                    fillOpacity={1} 
                                    fill="url(#colorSales)" 
                                  />
                                </AreaChart>
                              </ResponsiveContainer>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                            {sellerOrders.length > 0 && (
                              <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-black text-gray-900 dark:text-white">Recent Sales</h4>
                                  <button onClick={() => setSellerDashboardTab('sales')} className="text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400">View All</button>
                                </div>
                                <div className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
                                  <div className="overflow-x-auto">
                                    <table className="w-full border-collapse text-left">
                                      <thead>
                                        <tr className="border-b border-gray-50 bg-gray-50/50 dark:border-gray-800 dark:bg-gray-800/50">
                                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Product</th>
                                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Amount</th>
                                        </tr>
                                      </thead>
                                      <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                        {sellerOrders.slice(0, 3).map(order => (
                                          <tr key={order.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                                            <td className="px-6 py-4">
                                              <p className="text-sm font-bold text-gray-900 dark:text-white truncate max-w-[150px]">{order.productName}</p>
                                              <p className="text-[10px] text-gray-400">{new Date(order.createdAt?.toDate()).toLocaleDateString()}</p>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                              <p className="text-sm font-black text-indigo-600 dark:text-indigo-400">${order.price.toFixed(2)}</p>
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                              </div>
                            )}

                            {payoutRequests.length > 0 && (
                              <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-black text-gray-900 dark:text-white">Payout Status</h4>
                                  <button onClick={() => setSellerDashboardTab('payouts')} className="text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400">View History</button>
                                </div>
                                <div className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
                                  <div className="overflow-x-auto">
                                    <table className="w-full border-collapse text-left">
                                      <thead>
                                        <tr className="border-b border-gray-50 bg-gray-50/50 dark:border-gray-800 dark:bg-gray-800/50">
                                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Amount</th>
                                          <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Status</th>
                                        </tr>
                                      </thead>
                                      <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                        {payoutRequests.slice(0, 3).map(payout => (
                                          <tr key={payout.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                                            <td className="px-6 py-4">
                                              <p className="text-sm font-bold text-gray-900 dark:text-white">${payout.amount.toFixed(2)}</p>
                                              <p className="text-[10px] text-gray-400">{new Date(payout.createdAt?.toDate()).toLocaleDateString()}</p>
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                              <span className={cn(
                                                "rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider",
                                                payout.status === 'pending' ? "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" :
                                                payout.status === 'approved' ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" :
                                                "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"
                                              )}>
                                                {payout.status}
                                              </span>
                                            </td>
                                          </tr>
                                        ))}
                                      </tbody>
                                    </table>
                                  </div>
                                </div>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}

                      {sellerDashboardTab === 'products' && (
                        <motion.div
                          key="products"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="space-y-8"
                        >
                          <div className="flex items-center justify-between">
                            <h3 className="text-xl font-black text-gray-900 dark:text-white">Your Listings</h3>
                            <button 
                              onClick={() => {
                                setEditingProduct(null);
                                setProductVariants([]);
                                setIsAddingProduct(true);
                              }}
                              className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-700 transition-all active:scale-95"
                            >
                              <Plus size={16} />
                              Add Product
                            </button>
                          </div>

                          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 xl:grid-cols-3">
                            {products.filter(p => p.sellerId === user.uid).map(p => (
                              <ProductCard 
                                key={p.id} 
                                product={p} 
                                isOwner={true}
                                onClick={setSelectedProduct}
                                onEdit={(p) => {
                                  setEditingProduct(p);
                                  setProductVariants(p.variants || []);
                                  setIsAddingProduct(true);
                                }}
                                onDelete={handleDeleteProduct}
                              />
                            ))}
                            {products.filter(p => p.sellerId === user.uid).length === 0 && (
                              <div className="col-span-full flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-gray-200 rounded-3xl dark:border-gray-800">
                                <Store className="mb-4 text-gray-300 dark:text-gray-700" size={48} />
                                <h3 className="text-xl font-bold text-gray-900 dark:text-white">Start Selling!</h3>
                                <p className="mb-6 text-gray-500 dark:text-gray-400">You haven't listed any products yet.</p>
                                <button 
                                  onClick={() => setIsAddingProduct(true)}
                                  className="text-indigo-600 font-bold hover:underline dark:text-indigo-400"
                                >
                                  Create your first listing
                                </button>
                              </div>
                            )}
                          </div>
                        </motion.div>
                      )}

                      {sellerDashboardTab === 'sales' && (
                        <motion.div
                          key="sales"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="space-y-8"
                        >
                          <h3 className="text-xl font-black text-gray-900 dark:text-white">Sales History</h3>
                          
                          {sellerOrders.length > 0 ? (
                            <div className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="overflow-x-auto">
                                <table className="w-full border-collapse text-left">
                                  <thead>
                                    <tr className="border-b border-gray-50 bg-gray-50/50 dark:border-gray-800 dark:bg-gray-800/50">
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Order ID</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Product</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Date</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Amount</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                    {sellerOrders.map(order => (
                                      <tr key={order.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                                        <td className="px-6 py-4">
                                          <p className="text-xs font-mono text-gray-400">#{order.id.slice(-8)}</p>
                                        </td>
                                        <td className="px-6 py-4">
                                          <p className="text-sm font-bold text-gray-900 dark:text-white">{order.productName}</p>
                                        </td>
                                        <td className="px-6 py-4">
                                          <p className="text-sm text-gray-500 dark:text-gray-400">
                                            {new Date(order.createdAt?.toDate()).toLocaleDateString()}
                                          </p>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                          <p className="text-sm font-black text-indigo-600 dark:text-indigo-400">${order.price.toFixed(2)}</p>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-gray-200 rounded-3xl dark:border-gray-800">
                              <TrendingUp className="mb-4 text-gray-300 dark:text-gray-700" size={48} />
                              <h3 className="text-xl font-bold text-gray-900 dark:text-white">No sales yet</h3>
                              <p className="text-gray-500 dark:text-gray-400">Share your products to start earning!</p>
                            </div>
                          )}
                        </motion.div>
                      )}

                      {sellerDashboardTab === 'payouts' && (
                        <motion.div
                          key="payouts"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="space-y-8"
                        >
                          <div className="flex items-center justify-between">
                            <h3 className="text-xl font-black text-gray-900 dark:text-white">Payout History</h3>
                            <button 
                              onClick={() => {
                                setPayoutAmount('');
                                setIsPayoutModalOpen(true);
                              }}
                              disabled={(userProfile?.balance || 0) <= 0}
                              className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95"
                            >
                              <Wallet size={16} />
                              Request Payout
                            </button>
                          </div>

                          {payoutRequests.length > 0 ? (
                            <div className="overflow-hidden rounded-3xl border border-gray-100 bg-white shadow-sm dark:border-gray-800 dark:bg-gray-900">
                              <div className="overflow-x-auto">
                                <table className="w-full border-collapse text-left">
                                  <thead>
                                    <tr className="border-b border-gray-50 bg-gray-50/50 dark:border-gray-800 dark:bg-gray-800/50">
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Request ID</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Amount</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400">Status</th>
                                      <th className="px-6 py-4 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Date</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                                    {payoutRequests.map(payout => (
                                      <tr key={payout.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                                        <td className="px-6 py-4">
                                          <p className="text-xs font-mono text-gray-400">#{payout.id.slice(-8)}</p>
                                        </td>
                                        <td className="px-6 py-4">
                                          <p className="text-sm font-bold text-gray-900 dark:text-white">${payout.amount.toFixed(2)}</p>
                                        </td>
                                        <td className="px-6 py-4">
                                          <span className={cn(
                                            "rounded-full px-2 py-1 text-[10px] font-bold uppercase tracking-wider",
                                            payout.status === 'pending' ? "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" :
                                            payout.status === 'approved' ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" :
                                            "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"
                                          )}>
                                            {payout.status}
                                          </span>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                          <p className="text-sm text-gray-500 dark:text-gray-400">
                                            {new Date(payout.createdAt?.toDate()).toLocaleDateString()}
                                          </p>
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center py-20 text-center border-2 border-dashed border-gray-200 rounded-3xl dark:border-gray-800">
                              <Wallet className="mb-4 text-gray-300 dark:text-gray-700" size={48} />
                              <h3 className="text-xl font-bold text-gray-900 dark:text-white">No payouts yet</h3>
                              <p className="text-gray-500 dark:text-gray-400">Your payout history will appear here.</p>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </>
              ) : (
                <div className="w-full">
                  <BecomeSellerForm onSubmit={handleBecomeSeller} />
                </div>
              )}
            </motion.div>
          )}

          {view === 'my-purchases' && user && (
            <motion.div 
              key="my-purchases"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <h2 className="mb-8 text-3xl font-black text-gray-900 dark:text-white">My Purchases</h2>
              
              <div className="space-y-4">
                  {myPurchases.map(order => {
                    const product = products.find(p => p.id === order.productId);
                    const userReview = reviews.find(r => r.productId === order.productId && r.userId === user.uid);
                    
                    return (
                      <div 
                        key={order.id}
                        className="flex flex-col gap-6 rounded-3xl border border-gray-100 bg-white p-6 shadow-sm transition-all hover:shadow-md md:flex-row md:items-center md:justify-between dark:border-gray-800 dark:bg-gray-900"
                      >
                        <div className="flex items-center gap-4">
                          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                            <ShoppingBag size={32} />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-gray-900 dark:text-white">{order.productName}</h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400">Purchased on {new Date(order.createdAt?.toDate()).toLocaleDateString()}</p>
                            
                            {/* Review Status */}
                            <div className="mt-2 flex items-center gap-2">
                              {userReview ? (
                                <div className="flex items-center gap-1 text-sm font-medium text-amber-500">
                                  <span className="text-gray-400 dark:text-gray-500 mr-1">Your review:</span>
                                  {[1, 2, 3, 4, 5].map((star) => (
                                    <Star 
                                      key={star} 
                                      size={14} 
                                      fill={star <= userReview.rating ? "currentColor" : "none"} 
                                      className={star <= userReview.rating ? "text-amber-500" : "text-gray-300 dark:text-gray-700"}
                                    />
                                  ))}
                                </div>
                              ) : (
                                <span className="text-xs text-gray-400 dark:text-gray-500 italic">No review left yet</span>
                              )}
                            </div>
                          </div>
                        </div>
                          <div className="flex items-center justify-between gap-8 md:justify-end">
                            <div className="text-right">
                              <p className="text-sm font-medium text-gray-400 dark:text-gray-500">Price Paid</p>
                              <p className="text-xl font-black text-indigo-600 dark:text-indigo-400">${order.price}</p>
                            </div>
                            <div className="flex gap-2">
                              {product && (
                                <button 
                                  onClick={() => setSelectedProduct(product)}
                                  className="rounded-xl bg-gray-100 px-4 py-2 text-sm font-bold text-gray-600 hover:bg-gray-200 transition-all dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-gray-700"
                                >
                                  View Details
                                </button>
                              )}
                              {product ? (
                                <a 
                                  href={product.downloadUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-2 rounded-xl bg-green-600 px-4 py-2 text-sm font-bold text-white shadow-lg shadow-green-100 hover:bg-green-700 transition-all active:scale-95 dark:shadow-none"
                                >
                                  <Download size={16} />
                                  Download
                                </a>
                              ) : (
                                <div className="flex items-center gap-2 rounded-xl bg-gray-100 px-4 py-2 text-sm font-bold text-gray-400 dark:bg-gray-800 dark:text-gray-500">
                                  <AlertCircle size={16} />
                                  Unavailable
                                </div>
                              )}
                            </div>
                          </div>
                      </div>
                    );
                  })}
                {myPurchases.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-20 text-center">
                    <div className="mb-4 rounded-full bg-gray-100 p-6 text-gray-400 dark:bg-gray-900 dark:text-gray-600">
                      <ShoppingBag size={48} />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">No purchases yet</h3>
                    <p className="text-gray-500 dark:text-gray-400">Explore the marketplace to find amazing digital products.</p>
                    <button 
                      onClick={() => setView('marketplace')}
                      className="mt-6 rounded-2xl bg-indigo-600 px-8 py-3 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all dark:shadow-none"
                    >
                      Go to Marketplace
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
          {view === 'profile' && user && (
            <ProfileView 
              userProfile={userProfile}
              onUpdate={handleUpdateProfile}
              stats={{
                purchases: myPurchases.length,
                products: products.filter(p => p.sellerId === user.uid).length,
                sales: products.filter(p => p.sellerId === user.uid).reduce((acc, p) => acc + (p.salesCount || 0), 0)
              }}
              myProducts={products.filter(p => p.sellerId === user.uid)}
            />
          )}
          {view === 'admin-panel' && userProfile?.role === 'admin' && (
            <motion.div 
              key="admin-panel"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
            >
              <div className="mb-8 flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                <div>
                  <h2 className="text-3xl font-black text-gray-900 dark:text-white">Admin Panel</h2>
                  <p className="text-gray-500 dark:text-gray-400">Manage DigiCart users and products.</p>
                </div>
                <div className="flex items-center gap-2 rounded-2xl bg-gray-100 p-1 dark:bg-gray-800">
                  <button 
                    onClick={() => setAdminTab('users')}
                    className={cn(
                      "rounded-xl px-6 py-2 text-sm font-bold transition-all",
                      adminTab === 'users' 
                        ? "bg-white text-indigo-600 shadow-sm dark:bg-gray-700 dark:text-indigo-400" 
                        : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                    )}
                  >
                    Users
                  </button>
                  <button 
                    onClick={() => setAdminTab('products')}
                    className={cn(
                      "rounded-xl px-6 py-2 text-sm font-bold transition-all",
                      adminTab === 'products' 
                        ? "bg-white text-indigo-600 shadow-sm dark:bg-gray-700 dark:text-indigo-400" 
                        : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                    )}
                  >
                    Products
                  </button>
                  <button 
                    onClick={() => setAdminTab('payouts')}
                    className={cn(
                      "rounded-xl px-6 py-2 text-sm font-bold transition-all",
                      adminTab === 'payouts' 
                        ? "bg-white text-indigo-600 shadow-sm dark:bg-gray-700 dark:text-indigo-400" 
                        : "text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                    )}
                  >
                    Payouts
                  </button>
                </div>
              </div>

              {adminTab === 'users' && (
                <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
                  <h3 className="mb-8 text-xl font-bold flex items-center gap-2 dark:text-white">
                    <User className="text-indigo-600 dark:text-indigo-400" size={24} />
                    User Management
                  </h3>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
                    {allUsers.map(u => (
                      <div key={u.uid} className="flex items-center justify-between rounded-2xl border border-gray-50 p-4 transition-colors hover:bg-gray-50 dark:border-gray-800 dark:hover:bg-gray-800/50">
                        <div className="flex items-center gap-3">
                          <img src={u.photoURL || `https://ui-avatars.com/api/?name=${u.displayName}`} className="h-10 w-10 rounded-full" alt="" />
                          <div>
                            <p className="text-sm font-bold text-gray-900 dark:text-white">{u.displayName}</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">{u.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className={cn(
                            "rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider",
                            u.role === 'admin' ? "bg-indigo-100 text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400" : "bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400"
                          )}>
                            {u.role}
                          </span>
                          <button 
                            onClick={() => handleToggleAdmin(u)}
                            disabled={u.uid === user?.uid}
                            className={cn(
                              "text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400",
                              u.uid === user?.uid && "opacity-50 cursor-not-allowed no-underline"
                            )}
                          >
                            {u.role === 'admin' ? 'Revoke' : 'Make Admin'}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {adminTab === 'products' && (
                <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
                  <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <h3 className="text-xl font-bold flex items-center gap-2 dark:text-white">
                      <Store className="text-indigo-600 dark:text-indigo-400" size={24} />
                      Global Product Management
                    </h3>
                    <div className="relative w-full max-w-xs">
                      <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <input 
                        type="text" 
                        placeholder="Search products..."
                        value={adminSearchQuery}
                        onChange={(e) => setAdminSearchQuery(e.target.value)}
                        className="w-full rounded-2xl border border-gray-100 bg-gray-50 py-3 pl-12 pr-4 text-sm focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-left">
                      <thead>
                        <tr className="border-b border-gray-50 dark:border-gray-800">
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Product</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Seller</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Category</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Price</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Sales</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                        {products
                          .filter(p => p.name.toLowerCase().includes(adminSearchQuery.toLowerCase()) || p.sellerName.toLowerCase().includes(adminSearchQuery.toLowerCase()))
                          .map(p => (
                          <tr key={p.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                            <td className="py-4">
                              <div className="flex items-center gap-3">
                                <img src={p.imageUrl || `https://picsum.photos/seed/${p.id}/100/100`} className="h-12 w-12 rounded-xl object-cover" alt="" />
                                <div>
                                  <p className="text-sm font-bold text-gray-900 dark:text-white">{p.name}</p>
                                  <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">{p.description}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-4">
                              <p className="text-sm text-gray-600 dark:text-gray-400">{p.sellerName}</p>
                            </td>
                            <td className="py-4">
                              <span className="rounded-full bg-indigo-50 px-3 py-1 text-[10px] font-bold text-indigo-600 dark:bg-indigo-900/30 dark:text-indigo-400">
                                {p.category}
                              </span>
                            </td>
                            <td className="py-4 text-right">
                              <p className="text-sm font-black text-gray-900 dark:text-white">${p.price}</p>
                            </td>
                            <td className="py-4 text-right">
                              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{p.salesCount || 0}</p>
                            </td>
                            <td className="py-4 text-right">
                              <div className="flex justify-end gap-2">
                                <button 
                                  onClick={() => {
                                    setEditingProduct(p);
                                    setIsAddingProduct(true);
                                  }}
                                  className="rounded-lg p-2 text-gray-400 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-900/50 dark:hover:text-indigo-400 transition-colors"
                                >
                                  <Edit2 size={18} />
                                </button>
                                  <button 
                                    onClick={() => handleDeleteProduct(p)}
                                    className="rounded-lg p-2 text-gray-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/50 dark:hover:text-red-400 transition-colors"
                                  >
                                    <Trash2 size={18} />
                                  </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {adminTab === 'payouts' && (
                <div className="rounded-3xl border border-gray-100 bg-white p-8 shadow-xl dark:border-gray-800 dark:bg-gray-900">
                  <h3 className="mb-8 text-xl font-bold flex items-center gap-2 dark:text-white">
                    <Wallet className="text-indigo-600 dark:text-indigo-400" size={24} />
                    Payout Management
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse text-left">
                      <thead>
                        <tr className="border-b border-gray-50 dark:border-gray-800">
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Seller</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Amount</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Status</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400">Requested At</th>
                          <th className="pb-4 pt-0 text-xs font-bold uppercase tracking-wider text-gray-400 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                        {payoutRequests.map(payout => (
                          <tr key={payout.id} className="group hover:bg-gray-50/50 dark:hover:bg-gray-800/30">
                            <td className="py-4">
                              <p className="text-sm font-bold text-gray-900 dark:text-white">{payout.sellerName}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-400">{payout.sellerId}</p>
                            </td>
                            <td className="py-4">
                              <p className="text-sm font-black text-indigo-600 dark:text-indigo-400">${payout.amount.toFixed(2)}</p>
                            </td>
                            <td className="py-4">
                              <span className={cn(
                                "rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider",
                                payout.status === 'pending' ? "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" :
                                payout.status === 'approved' ? "bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400" :
                                "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400"
                              )}>
                                {payout.status}
                              </span>
                            </td>
                            <td className="py-4">
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                {new Date(payout.createdAt?.toDate()).toLocaleString()}
                              </p>
                            </td>
                            <td className="py-4 text-right">
                              {payout.status === 'pending' && (
                                <div className="flex justify-end gap-2">
                                  <button 
                                    onClick={() => handleApprovePayout(payout.id)}
                                    className="rounded-xl bg-green-600 px-4 py-2 text-xs font-bold text-white hover:bg-green-700 transition-all"
                                  >
                                    Approve
                                  </button>
                                  <button 
                                    onClick={() => handleRejectPayout(payout.id, payout.amount, payout.sellerId)}
                                    className="rounded-xl bg-red-600 px-4 py-2 text-xs font-bold text-white hover:bg-red-700 transition-all"
                                  >
                                    Reject
                                  </button>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                        {payoutRequests.length === 0 && (
                          <tr>
                            <td colSpan={5} className="py-12 text-center text-gray-500 dark:text-gray-400">
                              No payout requests found.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payout Modal */}
        <AnimatePresence>
          {isPayoutModalOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsPayoutModalOpen(false)}
                className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white p-8 shadow-2xl dark:bg-gray-900"
              >
                <div className="mb-6 flex items-center justify-between">
                  <h3 className="text-2xl font-black text-gray-900 dark:text-white">Request Payout</h3>
                  <button 
                    onClick={() => setIsPayoutModalOpen(false)}
                    className="rounded-full p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
                  >
                    <X size={20} />
                  </button>
                </div>
                
                <div className="mb-6 rounded-2xl bg-indigo-50 p-4 dark:bg-indigo-900/20">
                  <p className="text-sm font-medium text-indigo-600 dark:text-indigo-400">Available Balance</p>
                  <p className="text-2xl font-black text-gray-900 dark:text-white">${(userProfile?.balance || 0).toFixed(2)}</p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="mb-2 block text-sm font-bold text-gray-700 dark:text-gray-300">Amount to Withdraw</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                      <input 
                        type="number" 
                        step="0.01"
                        value={payoutAmount}
                        onChange={(e) => setPayoutAmount(e.target.value)}
                        placeholder="0.00"
                        className="w-full rounded-2xl border border-gray-100 bg-gray-50 py-4 pl-12 pr-4 font-bold focus:border-indigo-500 focus:bg-white focus:outline-none focus:ring-4 focus:ring-indigo-500/10 dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:border-indigo-500 dark:focus:bg-gray-900"
                      />
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => {
                      const val = parseFloat(payoutAmount);
                      if (!isNaN(val) && val > 0 && val <= (userProfile?.balance || 0)) {
                        handleRequestPayout(val);
                        setIsPayoutModalOpen(false);
                      }
                    }}
                    disabled={!payoutAmount || parseFloat(payoutAmount) <= 0 || parseFloat(payoutAmount) > (userProfile?.balance || 0)}
                    className="w-full rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all active:scale-95 dark:shadow-none"
                  >
                    Confirm Withdrawal
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </main>

      {/* Add/Edit Product Modal */}
      <AnimatePresence>
        {isAddingProduct && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingProduct(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="relative w-full max-w-2xl rounded-3xl bg-white p-8 shadow-2xl dark:bg-gray-900 dark:shadow-none"
            >
              <h2 className="mb-6 text-2xl font-black text-gray-900 dark:text-white">
                {editingProduct ? 'Edit Product' : 'List New Product'}
              </h2>

              {!editingProduct && (
                <div className="mb-8 p-6 border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50 dark:bg-gray-800/50 dark:border-gray-800">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-gray-900 dark:text-white">Bulk Upload</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">Upload a CSV file to list multiple products at once.</p>
                    </div>
                    <FileUp className="text-indigo-600" size={24} />
                  </div>
                  <input 
                    type="file" 
                    accept=".csv"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleBulkUpload(file);
                    }}
                    className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 dark:file:bg-indigo-900/30 dark:file:text-indigo-400"
                  />
                  <div className="mt-4 flex items-center justify-between">
                    <p className="text-[10px] text-gray-400">CSV Columns: name, price, category, subCategory, tags, description, downloadUrl, imageUrl (optional)</p>
                    <button 
                      type="button"
                      onClick={() => {
                        const csvContent = "name,price,category,subCategory,tags,description,downloadUrl,imageUrl\nSample Product,19.99,Software,Web Tools,\"react,ui,kit\",A great product,https://example.com/file.zip,https://example.com/image.png";
                        const blob = new Blob([csvContent], { type: 'text/csv' });
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.setAttribute('hidden', '');
                        a.setAttribute('href', url);
                        a.setAttribute('download', 'sample_products.csv');
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                      }}
                      className="text-[10px] font-bold text-indigo-600 hover:underline dark:text-indigo-400"
                    >
                      Download Sample CSV
                    </button>
                  </div>
                </div>
              )}

              <form onSubmit={handleAddProduct} className="space-y-6">
                <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Product Name</label>
                    <input 
                      name="name" 
                      required 
                      defaultValue={editingProduct?.name}
                      placeholder="e.g. Modern UI Kit"
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Price ($)</label>
                    <input 
                      name="price" 
                      type="number" 
                      step="0.01" 
                      required 
                      defaultValue={editingProduct?.price}
                      placeholder="0.00"
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Category</label>
                    <select 
                      name="category" 
                      required 
                      defaultValue={editingProduct?.category || 'Software'}
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    >
                      {categories.filter(c => c !== 'All').map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Sub-Category (Optional)</label>
                    <input 
                      name="subCategory" 
                      defaultValue={editingProduct?.subCategory}
                      placeholder="e.g. UI Kits, Templates"
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Tags (Comma separated)</label>
                    <input 
                      name="tags" 
                      defaultValue={editingProduct?.tags?.join(', ')}
                      placeholder="e.g. react, tailwind, dashboard"
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Image URL (Optional)</label>
                    <input 
                      name="imageUrl" 
                      defaultValue={editingProduct?.imageUrl}
                      placeholder="https://..."
                      className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Description</label>
                  <textarea 
                    name="description" 
                    required 
                    rows={3}
                    defaultValue={editingProduct?.description}
                    placeholder="Describe your digital product..."
                    className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300">Download Link (The actual product file)</label>
                  <input 
                    name="downloadUrl" 
                    required 
                    defaultValue={editingProduct?.downloadUrl}
                    placeholder="https://your-storage-link.com/file.zip"
                    className="w-full rounded-xl border border-gray-200 px-4 py-3 focus:border-indigo-500 focus:outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all dark:border-gray-800 dark:bg-gray-800 dark:text-white dark:focus:ring-indigo-500/20"
                  />
                  <p className="text-xs text-gray-400 dark:text-gray-500">Make sure this link is accessible to buyers.</p>
                </div>

                {/* Product Variants */}
                <div className="space-y-4 border-t border-gray-100 pt-6 dark:border-gray-800">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-gray-400">Product Variants (Optional)</h3>
                    <button 
                      type="button"
                      onClick={() => setProductVariants([...productVariants, { id: Math.random().toString(36).substr(2, 9), name: '', price: 0 }])}
                      className="flex items-center gap-1 text-xs font-bold text-indigo-600 hover:underline dark:text-indigo-400"
                    >
                      <Plus size={14} />
                      Add Variant
                    </button>
                  </div>
                  
                  {productVariants.map((variant, index) => (
                    <div key={variant.id} className="flex items-end gap-4 rounded-2xl bg-gray-50 p-4 dark:bg-gray-800/50">
                      <div className="flex-1 space-y-2">
                        <label className="text-[10px] font-bold text-gray-500 uppercase">Variant Name</label>
                        <input 
                          value={variant.name}
                          onChange={(e) => {
                            const newVariants = [...productVariants];
                            newVariants[index].name = e.target.value;
                            setProductVariants(newVariants);
                          }}
                          placeholder="e.g. 4K Video, SVG Format"
                          className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white"
                        />
                      </div>
                      <div className="w-24 space-y-2">
                        <label className="text-[10px] font-bold text-gray-500 uppercase">Price ($)</label>
                        <input 
                          type="number"
                          step="0.01"
                          value={variant.price}
                          onChange={(e) => {
                            const newVariants = [...productVariants];
                            newVariants[index].price = parseFloat(e.target.value) || 0;
                            setProductVariants(newVariants);
                          }}
                          className="w-full rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none dark:border-gray-700 dark:bg-gray-900 dark:text-white"
                        />
                      </div>
                      <button 
                        type="button"
                        onClick={() => setProductVariants(productVariants.filter((_, i) => i !== index))}
                        className="mb-1 rounded-xl p-2 text-gray-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/30"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                  {productVariants.length === 0 && (
                    <p className="text-xs text-center text-gray-400 py-4">No variants added yet.</p>
                  )}
                </div>

                <div className="flex gap-4 pt-4">
                  <button 
                    type="button"
                    onClick={() => setIsAddingProduct(false)}
                    className="flex-1 rounded-2xl border border-gray-200 py-4 font-bold text-gray-600 hover:bg-gray-50 transition-all dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-800"
                  >
                    Cancel
                  </button>
                  <button 
                    type="submit"
                    disabled={isGeneratingImage}
                    className="flex-1 rounded-2xl bg-indigo-600 py-4 font-bold text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 dark:shadow-none"
                  >
                    {isGeneratingImage && <Loader2 className="animate-spin" size={20} />}
                    {isGeneratingImage ? 'Generating Image...' : (editingProduct ? 'Save Changes' : 'List Product')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ProductDetailsModal 
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onBuy={handleBuy}
        reviews={reviews}
        hasPurchased={myPurchases.some(o => o.productId === selectedProduct?.id)}
        onAddReview={handleAddReview}
      />

      <SuccessModal 
        isOpen={isSuccessModalOpen} 
        onClose={() => setIsSuccessModalOpen(false)} 
        onViewPurchases={() => setView('my-purchases')}
        productName={purchasedProductName} 
      />

      <DeleteConfirmationModal 
        isOpen={!!productToDelete}
        onClose={() => setProductToDelete(null)}
        onConfirm={confirmDeleteProduct}
        title="Delete Product?"
        message={`Are you sure you want to delete "${productToDelete?.name}"? This action cannot be undone and it will be removed from the marketplace.`}
      />

      {/* Footer */}
      <footer className="mt-20 border-t border-gray-100 bg-white py-16 dark:border-gray-800 dark:bg-gray-950">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="mb-12 flex flex-col items-center justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <motion.h2 
                animate={{ 
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                }}
                transition={{ 
                  duration: 5,
                  repeat: Infinity,
                  ease: "linear"
                }}
                className="text-7xl font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500 md:text-9xl dark:from-indigo-400 dark:via-purple-400 dark:to-pink-400"
                style={{ backgroundSize: '200% auto' }}
              >
                RAKESH
              </motion.h2>
              <motion.div 
                animate={{ 
                  scaleX: [0, 1, 0],
                  opacity: [0, 1, 0]
                }}
                transition={{ 
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="absolute -bottom-4 left-0 h-1.5 w-full rounded-full bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500"
              />
            </motion.div>
            <p className="mt-8 text-sm font-bold uppercase tracking-widest text-gray-400 dark:text-gray-600">
              Creative Visionary & Lead Designer
            </p>
          </div>

          <div className="flex flex-col items-center justify-between gap-6 border-t border-gray-50 pt-12 md:flex-row dark:border-gray-900">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white">
                <ShoppingBag size={18} />
              </div>
              <span className="text-lg font-bold tracking-tight text-gray-900 dark:text-white">DigiCart</span>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              © 2026 DigiCart Marketplace. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
